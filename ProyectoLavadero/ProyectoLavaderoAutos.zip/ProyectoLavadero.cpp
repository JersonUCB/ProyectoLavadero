#include <iostream>
#include "AdmiLavadero.h"

int main()
{
    AdmiLavadero lavadero;
    lavadero.run();
    return 0;
}
