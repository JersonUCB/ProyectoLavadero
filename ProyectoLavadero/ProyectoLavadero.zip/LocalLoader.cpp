#include "LocalLoader.h"

LocalLoader::LocalLoader()
{
}

LocalLoader::~LocalLoader()
{
}

vector<Camioneta*> LocalLoader::vectorCamioneta()
{
	return vector<Camioneta*>();
}

vector<Automovil*> LocalLoader::vectorAutomovil()
{
	return vector<Automovil*>();
}

vector<Cliente*> LocalLoader::vectorCliente()
{
	return vector<Cliente*>();
}

vector<Moto*> LocalLoader::vectorMoto()
{
	return vector<Moto*>();
}

vector<Vehiculo*> LocalLoader::vectorVehiculo()
{
	return vector<Vehiculo*>();
}

vector<Trabajador*> LocalLoader::vectorTrabajador()
{
	return vector<Trabajador*>();
}




