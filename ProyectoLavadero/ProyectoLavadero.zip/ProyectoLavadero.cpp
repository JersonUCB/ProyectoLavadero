#include <iostream>
#include "AdmiLavadero.h"

int main()
{
    AdmiLavadero bobEsponjaWash;
    bobEsponjaWash.run();
    return 0;
    //probar
}
